# Bomo
Coupon promotion upload from SmartPhone (Android only)

Tools / Frameworks / Language:
Frontend:
Android Studio
PhoneGap
HTML / CSS
Javascript
Jquery

Backend:
Drupal 7+

*The hyperlink in the file below that links to the backend website is unavailable now.

app/src/main/assets/www/scripts/check_connection.js

Setup Process:
1. Clone this repository
2. Use Android Studio to open / import this project
3. "Build"->"Make Project"
4. Run on Android Virtal Device or Android OS Smart Phone
